<HTML>
<HEAD>
<TITLE>Moving DIV Element using jQuery</TITLE>
<style>
body{width:610px;}
#movable {position:absolute;border:#D8F9D3 5px solid;background:#F9F9F9;height:200px;width:200px;line-height:150px;border-radius:4px;}
.arrow{margin:1px;width: 20px;height: 20px;}
.move-icon{text-align:center;margin:100px 0px 0px 100px;}
</style>
<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
<script type="text/javascript">
function moveDIV(action) {
	switch(action) {
		case "up":
			$('#movable').animate({'marginTop' : "-=15px"});
		break;
		case "left":
			$('#movable').animate({'marginLeft' : "-=15px"});
		break;
		case "right":
			$('#movable').animate({'marginLeft' : "+=15px"});
		break;
		case "down":
			$('#movable').animate({'marginTop' : "+=15px"});
		break;
	}
}
</script>
</HEAD>
<BODY>
<div id="movable">
	<div class="move-icon">
	<div><img src="up.jpg" class="arrow" onClick="moveDIV('up');" /></div>
	<div><img src="left.jpg" class="arrow"  onClick="moveDIV('left');" /><img class="arrow"  src="right.jpg" onClick="moveDIV('right');" /></div>
	<div><img src="down.jpg" class="arrow"  onClick="moveDIV('down');" /></div>
	</div>
</div>
</BODY>
</HTML>
